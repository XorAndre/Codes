A Pen created at CodePen.io. You can find this one at http://codepen.io/AndreRodrigues/pen/Vpxjdg.

 Desenho da vida do jogo Super Mario feito do zero.